import { heightAt, type Hill } from "../sim/hill";
import type { V } from "../sim/math";

// One fixed iso shot. Whole playable hill in 1280x720, no pan, no follow.
export const W = 1280;
export const H = 720;
export const A = 30; // px per world unit along each iso axis
export const OX = 640;
export const OY = 404;
export const ZS = 34; // px per metre of height

export interface S {
  x: number;
  y: number;
}

export const iso = (x: number, y: number, z = 0): S => ({ x: OX + (x + y) * A, y: OY + (y - x) * A * 0.5 - z * ZS });
export const isoV = (p: V, z = 0) => iso(p.x, p.y, z);

export function unIso(sx: number, sy: number): V {
  const u = (sx - OX) / A, w = (sy - OY) / (A * 0.5);
  return { x: (u - w) / 2, y: (u + w) / 2 };
}

/** Screen point -> point on the hill surface (iterates against the visual height). */
export function pickGround(h: Hill, sx: number, sy: number): V {
  let p = unIso(sx, sy);
  for (let i = 0; i < 4; i++) p = unIso(sx, sy + heightAt(h, p) * ZS);
  return p;
}

/** Screen-space direction (e.g. WASD) -> world-space direction. */
export function screenDirToWorld(dx: number, dy: number): V {
  const x = dx - 2 * dy, y = dx + 2 * dy;
  const l = Math.hypot(x, y);
  return l > 1e-6 ? { x: x / l, y: y / l } : { x: 0, y: 0 };
}

/** Screen ellipse radii for a world circle of radius r. */
export const ringRadii = (r: number) => ({ rx: Math.SQRT2 * r * A, ry: (Math.SQRT2 * r * A) / 2 });
